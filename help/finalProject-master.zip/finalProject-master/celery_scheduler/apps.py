from django.apps import AppConfig


class CelerySchedulerConfig(AppConfig):
    name = 'celery_scheduler'
