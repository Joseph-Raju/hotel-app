from django.apps import AppConfig


class StubapiConfig(AppConfig):
    name = 'stubapi'
